# 来源与素材说明

核对日期：2026-10-09（北京时间）。本次仅核对以下两篇微软官方帮助文档，已成功打开正文；未扩展其他研究。页面未显示明确发布日期，以下记录访问日期，不将抓取时间当作发布日期。

## [1] 指定文件夹内搜索

- 标题：Find your files and apps in Windows
- 发布者：Microsoft Support（微软官方）
- 链接：https://support.microsoft.com/en-us/windows/experience/storage-filemanagement/find-your-files-and-apps-in-windows
- 访问日期：2026-10-09
- 核对位置：Find your files → Search from File Explorer。
- 可支持的事实：可以选定文件夹作为文件资源管理器的搜索位置。
- 本文对应：“文件资源管理器支持从指定文件夹搜索”。示例中的项目名与文件名由本稿原创，不是微软示例。

## [2] 固定到快速访问

- 标题：File Explorer in Windows
- 发布者：Microsoft Support（微软官方）
- 链接：https://support.microsoft.com/en-us/windows/experience/fileexplorer/file-explorer-in-windows
- 访问日期：2026-10-09
- 核对位置：How to use File Explorer、Quick access。
- 可支持的事实：右键文件夹后，可选择 Pin to Quick access（固定到快速访问）。
- 本文对应：为正在推进的项目设置快速访问入口。

## 建议与事实的区分

按项目分类、“资料／进行中／交付”三个子文件夹、日期与版本命名、每周整理和按年归档均为本稿的实践建议，不是微软强制规范。文中没有效率测量、节省时间的统计或保证。示例文件与目录均为虚构；本任务未对用户工作文件执行整理、重命名、移动或删除。

## 原创素材

- `cover.svg`：本次原创矢量排版与文件夹图形，含中文标题、三条整理要点；无外部图片、商标、脚本或网络依赖。
- `cover.png`：同一布局用本地 Pillow 绘制的 1800 × 900 像素 PNG，供手动上传使用。此尺寸为本稿设计选择，不声称为平台强制规格。
- SVG 中文使用系统字体栈 `Microsoft YaHei, PingFang SC, Noto Sans CJK SC, sans-serif`；PNG 使用本机已安装的微软雅黑渲染，不包含或分发字体文件。
- 未调用图片生成服务或额外付费 API。

## 文件使用

`content.md` 为文案原稿；`article.html` 为相同内容的内联样式 HTML。用浏览器打开 HTML 可查看并复制正文，正文不依赖外部图片或脚本。封面独立提供，手动发布时使用 PNG。实际编辑器粘贴和封面裁切尚未核验，详见 `limitations.md`。
