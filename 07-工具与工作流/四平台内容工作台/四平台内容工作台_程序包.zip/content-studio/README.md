# 四平台内容工作台

输入话题，分别准备公众号、小红书、今日头条和抖音的素材。页面可以查看生成状态，预览和修改文案，播放视频，下载素材包，并将选定平台的素材上传到已指定的 GitHub 仓库。最终在各个平台手动发表。

## 迁到个人 Windows 电脑

1. 将程序压缩包解压到一个固定目录，例如 `D:\ContentStudio`。需要 Python 3.10 或更新版本、Git、Node.js。网页后端仅使用 Python 标准库，没有 pip 安装步骤。
2. 安装 Codex CLI：`npm install -g @openai/codex`，然后执行 `codex login`，使用自己的 ChatGPT 账号登录。生成会使用该账号的 Codex 额度。无需在本系统填写 API key。CLI 官方说明：https://developers.openai.com/codex/noninteractive 。
3. 为 Git 设置自己的提交姓名和邮箱，并让 Git Credential Manager 登录可访问这些私有仓库的 GitHub 账号。可先运行 `git ls-remote https://github.com/panchao9527/weixin.git` 检查访问。
4. 双击 `start-local.cmd`，在电脑浏览器打开 `http://127.0.0.1:8765`，输入启动窗口显示的配对码。
5. 需要手机访问时，关闭本机启动窗口，双击 `start-lan.cmd`。手机与个人电脑连同一 Wi-Fi，输入启动窗口中的手机地址和配对码。若 Windows 防火墙询问，仅允许你自己的专用网络。无需开放公网端口。

第一次点击“导入 GitHub 素材”可以读取此前四个平台的素材。自动生成需要 Codex 能正常联网；网络或 Windows 沙箱阻止任务执行时会显示错误日志并保留已有素材。视频生成还取决于本地可用媒体工具，缺少实际视频或来源记录会显示“素材待补齐”，不能当作完成。

需要制作图片、视频时，个人电脑可安装媒体依赖：`python -m pip install pillow imageio-ffmpeg`。这两个库不是打开工作台的必需项。配音可以使用 Windows 自带的语音引擎；画面复杂度和实际质量需要逐期预览确认。

## 页面操作

- 新建话题：输入话题、补充要求和平台，点击“创建并生成”。后台串行处理任务；浏览器关闭后任务仍可继续，电脑上的服务窗口必须保持运行。
- 素材预览：选择作品、平台和文件。支持 Markdown、HTML、图片、音频、视频、字幕与 JSON。
- 编辑文案：点“编辑文案”后保存。不会改动原仓库。正在生成的素材不能同时编辑；多个页面修改同一文件会检查冲突。
- 修改会保存到当前选中的文件。Markdown 与 HTML、图片里的文字、已渲染的视频是独立素材，改动其中之一后需要检查其他版本是否一致。
- 上传 GitHub：在对应平台点“上传此平台到 GitHub”。使用本机 Git 登录，核对远端提交后显示链接。远端原素材有变化时停止覆盖。每个平台分别上传。
- 下载：可下载单个文件或整个话题的素材 ZIP，之后由你在平台手动发表。

仓库对应：公众号 `panchao9527/weixin`，小红书 `panchao9527/xiaohongshu`，今日头条 `panchao9527/jinritoutiao`，抖音 `panchao9527/titok`。页面不提供任意 shell 命令或任意仓库地址入口。

## 作品数据与备份

任务保存在 `data/studio.sqlite3`；素材在 `data/tasks/`。`data/repos/` 是 Git 临时 checkout，可以在新电脑重新克隆。Skill 的参考副本在 `skill/`，程序不依赖公司电脑上的安装路径。

运行 `python backup.py --output 作品备份.zip` 可导出任务和素材，不包含 Codex/GitHub 登录信息、Git checkout、运行日志或配对会话。为了确保生成中的媒体完整，先等任务结束再备份。个人电脑首次启动前将备份解压到程序目录即可恢复作品。不要在已有作品数据库上覆盖备份。

公司电脑上的程序演示只监听本机地址。移到个人电脑后重新登录 Codex 和 GitHub，配对码也会重新生成。局域网模式只用于可信任的家庭 Wi-Fi；这是单人工作台，没有公网部署、多用户权限和 TLS。

## 验证

运行 `python -m unittest discover -s tests -v`。覆盖配对、未授权访问、任务持久化、迁移、文件越界、编辑冲突、媒体范围请求和模拟 Git 仓库上传。测试不会向真实 GitHub 仓库推送，也不会消耗 Codex 生成额度。
