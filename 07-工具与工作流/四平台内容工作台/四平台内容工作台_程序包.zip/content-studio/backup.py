"""导出作品和任务，不打包登录、仓库 checkout、配对会话或运行日志。"""
import argparse
from pathlib import Path
import sqlite3
import tempfile
import zipfile
from server import Studio, assets, safe_file

def backup(data, output):
    data = Path(data).resolve()
    output = Path(output).resolve()
    if not (data / 'studio.sqlite3').exists():
        raise ValueError('没有任务数据库')
    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / 'studio.sqlite3'
        source = sqlite3.connect(data / 'studio.sqlite3')
        dest = sqlite3.connect(copy)
        try:
            source.backup(dest)
        finally:
            source.close()
            dest.close()
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(copy, 'data/studio.sqlite3')
            tasks = data / 'tasks'
            if tasks.exists():
                for task in tasks.iterdir():
                    for key in ('wechat', 'xiaohongshu', 'toutiao', 'douyin'):
                        folder = task / key
                        for item in assets(folder):
                            z.write(safe_file(folder, item['path']), f'data/tasks/{task.name}/{key}/{item["path"]}')
    print('作品备份已生成：', output)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data', default=str(Path(__file__).parent / 'data'))
    p.add_argument('--output', default='作品备份.zip')
    a = p.parse_args()
    backup(a.data, a.output)
