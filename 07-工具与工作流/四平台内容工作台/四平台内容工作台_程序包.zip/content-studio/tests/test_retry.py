import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import Studio


class RecoveryTests(unittest.TestCase):
    def test_retry_preserves_edited_original_and_queues_independent_copy(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = Studio(Path(tmp) / 'data')
            original = app.create({'topic': '重试检查', 'brief': '保留角度', 'platforms': ['wechat']})
            original['status'] = 'partial'
            app.save(original)
            source = Path(original['packages']['wechat']['folder']) / 'content.md'
            source.write_text('用户已经修改的稿件', encoding='utf-8')
            with patch('server.codex_command', return_value=['codex']), patch.object(app.jobs, 'put') as enqueue:
                new_id = app.retry(original['id'])
                enqueue.assert_called_once_with(new_id)
            copied = app.task(new_id)
            self.assertEqual(source.read_text(encoding='utf-8'), '用户已经修改的稿件')
            self.assertNotEqual(copied['packages']['wechat']['remote_path'], original['packages']['wechat']['remote_path'])
            self.assertEqual(copied['brief'], original['brief'])
            self.assertEqual(copied['status'], 'queued')
            self.assertEqual(copied['retry_of'], original['id'])
            self.assertEqual(app.task(original['id'])['status'], 'partial')
            with self.assertRaises(ValueError):
                app.retry(new_id)

    def test_empty_files_and_source_notes_do_not_count_as_complete_article(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = Studio(Path(tmp) / 'data')
            folder = Path(tmp) / 'assets'
            folder.mkdir()
            (folder / 'sources.md').write_text('来源记录', encoding='utf-8')
            (folder / 'content.md').touch()
            (folder / 'cover.png').touch()
            result = app.checks(folder, 'wechat')
            self.assertTrue(result['来源记录'])
            self.assertFalse(result['文案'])
            self.assertFalse(result['配图'])
            self.assertFalse(result['排版 HTML'])

