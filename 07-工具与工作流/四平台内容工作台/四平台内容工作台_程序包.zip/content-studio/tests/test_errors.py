import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import Studio, generation_error_message


class GenerationErrorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.log = Path(self.tmp.name) / 'events.log'

    def write_events(self, *events):
        self.log.write_text('\n'.join(json.dumps(event, ensure_ascii=False) for event in events), encoding='utf-8')

    def test_usage_limit_from_real_cli_error_format(self):
        message = 'You’ve hit your usage limit. Upgrade to Pro or try again at Oct 9th, 2026 1:02 AM.'
        self.write_events({'type': 'error', 'message': message}, {'type': 'turn.failed', 'error': {'message': message}})
        result = generation_error_message(self.log)
        self.assertIn('额度已用尽', result)
        self.assertIn('等待额度恢复', result)
        self.assertNotIn('Upgrade', result)
        self.assertNotIn('1:02', result)

    def test_expired_or_reused_login_token_has_recovery_instruction(self):
        for message in ('Your authentication token has expired. Please log in again.',
                        'Your refresh token could not be refreshed because it was already used. Please log out and sign in again.'):
            with self.subTest(message=message):
                self.write_events({'type': 'turn.failed', 'error': {'message': message}})
                result = generation_error_message(self.log)
                self.assertIn('登录状态无效或已过期', result)
                self.assertIn('codex login', result)

    def test_final_error_takes_precedence_over_transient_errors(self):
        self.write_events({'type': 'error', 'message': '401 Unauthorized'},
                          {'type': 'turn.failed', 'error': {'message': 'Connection closed unexpectedly'}})
        result = generation_error_message(self.log)
        self.assertIn('Connection closed unexpectedly', result)
        self.assertNotIn('登录状态', result)

    def test_unknown_error_is_short_and_does_not_include_other_event_data(self):
        self.write_events({'type': 'item.completed', 'item': {'text': 'PRIVATE RESEARCH BODY'}},
                          {'type': 'error', 'message': 'Network failure\n  with diagnostics ' + 'x' * 1000,
                           'details': 'PRIVATE DEBUG PAYLOAD'})
        result = generation_error_message(self.log)
        self.assertIn('Network failure with diagnostics', result)
        self.assertLess(len(result), 280)
        self.assertNotIn('\n', result)
        self.assertNotIn('PRIVATE', result)

    def test_rate_limit_and_token_network_failure_are_not_misclassified(self):
        for message in ('Rate limit exceeded; retry in 2 seconds.',
                        'Failed to refresh token: connection timed out.'):
            with self.subTest(message=message):
                self.write_events({'type': 'error', 'message': message})
                result = generation_error_message(self.log)
                self.assertIn(message, result)
                self.assertNotIn('额度已用尽', result)
                self.assertNotIn('登录状态', result)

    def test_missing_or_malformed_log_keeps_generic_failure_message(self):
        expected = 'Codex 执行失败，请查看日志。已有文件仍可下载。'
        self.assertEqual(generation_error_message(self.log), expected)
        self.log.write_text('process stderr\n{broken json\n[]\n{"type":"error","message":{}}', encoding='utf-8')
        self.assertEqual(generation_error_message(self.log), expected)

    def test_failed_generation_saves_actionable_status_and_preserves_files(self):
        app = Studio(Path(self.tmp.name) / 'data')
        task = app.create({'topic': '失败提示检查', 'platforms': ['wechat']})
        output = Path(task['packages']['wechat']['folder']) / 'content.md'

        def process(args, **kwargs):
            class FailedProcess:
                returncode = 1

                def communicate(self, data):
                    output.write_text('已生成的部分文案', encoding='utf-8')
                    kwargs['stdout'].write(json.dumps({'type': 'turn.failed', 'error': {'message': "You've hit your usage limit."}}) + '\n')

            return FailedProcess()

        with patch('server.codex_command', return_value=['codex']), patch('server.subprocess.run') as login, patch('server.subprocess.Popen', side_effect=process):
            login.return_value.returncode = 0
            login.return_value.stdout = 'Logged in using ChatGPT'
            login.return_value.stderr = ''
            app.run_generation(task['id'])
        stored = app.task(task['id'])
        self.assertEqual(stored['status'], 'failed')
        self.assertIn('额度已用尽', stored['message'])
        self.assertEqual(output.read_text(encoding='utf-8'), '已生成的部分文案')


if __name__ == '__main__':
    unittest.main()
