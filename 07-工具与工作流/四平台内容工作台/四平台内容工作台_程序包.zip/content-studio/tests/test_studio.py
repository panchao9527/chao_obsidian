import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import Studio, Handler, ThreadingHTTPServer, safe_file, zip_assets, cmd
from backup import backup

class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = Studio(Path(self.tmp.name) / 'data')
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.http.app = self.app
        threading.Thread(target=self.http.serve_forever, daemon=True).start()
        self.url = 'http://127.0.0.1:' + str(self.http.server_port)
        self.cookie = ''

    def tearDown(self):
        self.http.shutdown()
        self.http.server_close()
        self.tmp.cleanup()

    def request(self, path, body=None, headers=None):
        hs = {'Cookie': self.cookie}
        if body is not None:
            hs.update({'X-Studio-Request': '1', 'Content-Type': 'application/json'})
        hs.update(headers or {})
        req = urllib.request.Request(self.url + path, data=json.dumps(body).encode() if body is not None else None, headers=hs)
        try:
            return urllib.request.urlopen(req)
        except urllib.error.HTTPError as e:
            return e

    def login(self):
        r = self.request('/api/login', {'pin': self.app.pin})
        self.assertEqual(r.status, 200)
        self.cookie = r.headers['Set-Cookie'].split(';')[0]

    def create(self):
        return self.app.create({'topic': '手机 CPU 怎么选', 'platforms': ['wechat', 'douyin']})

    def test_login_and_modification_boundary(self):
        self.assertEqual(self.request('/api/state').status, 401)
        self.assertEqual(self.request('/api/login', {'pin': 'wrong'}).status, 401)
        self.login()
        self.assertEqual(self.request('/api/state').status, 200)
        self.assertEqual(self.request('/api/tasks', {'topic': 'x', 'platforms': ['wechat']}, {'X-Studio-Request': ''}).status, 403)
        r = self.request('/api/tasks', {'topic': '测试话题', 'platforms': ['wechat']})
        self.assertEqual(r.status, 201)
        t = json.loads(r.read())
        self.assertNotIn('folder', t['packages']['wechat'])
        self.assertEqual(self.request('/api/tasks', {'topic': 'x', 'platforms': ['bad']}).status, 400)

    def test_edit_conflict_range_and_download(self):
        t = self.create()
        folder = Path(t['packages']['wechat']['folder'])
        f = folder / 'content.md'
        f.write_text('# 原稿', encoding='utf-8')
        (folder / 'sample.mp4').write_bytes(bytes(range(256)))
        self.login()
        endpoint = '/api/tasks/' + t['id'] + '/wechat/'
        version = hashlib.sha256(f.read_bytes()).hexdigest()
        r = self.request(endpoint + 'edit', {'path': 'content.md', 'text': '# 修改', 'version': version})
        self.assertEqual(r.status, 200)
        self.assertEqual(f.read_text(encoding='utf-8'), '# 修改')
        self.assertEqual(self.request(endpoint + 'edit', {'path': 'content.md', 'text': '旧页面', 'version': version}).status, 409)
        self.assertEqual(self.request(endpoint + 'file?path=../../studio.sqlite3').status, 400)
        r = self.request(endpoint + 'file?path=sample.mp4', headers={'Range': 'bytes=10-19'})
        self.assertEqual(r.status, 206)
        self.assertEqual(r.read(), bytes(range(10, 20)))
        self.assertEqual(r.headers['Content-Range'], 'bytes 10-19/256')
        r = self.request('/api/tasks/' + t['id'] + '/download')
        z = zipfile.ZipFile(io.BytesIO(r.read()))
        self.assertIn('wechat/content.md', z.namelist())

    def test_data_backup_and_relocation(self):
        t = self.create()
        folder = Path(t['packages']['wechat']['folder'])
        (folder / 'content.md').write_text('迁移后的作品', encoding='utf-8')
        (folder.parent / 'events.log').write_text('不要迁移运行日志')
        self.app.save(t)
        archive = Path(self.tmp.name) / 'backup.zip'
        backup(self.app.data, archive)
        moved = Path(self.tmp.name) / 'another-computer'
        with zipfile.ZipFile(archive) as z:
            self.assertFalse(any('events.log' in x or 'repos/' in x for x in z.namelist()))
            z.extractall(moved)
        other = Studio(moved / 'data')
        restored = other.task(t['id'])
        self.assertTrue(Path(restored['packages']['wechat']['folder']).is_relative_to(moved))
        self.assertEqual(Path(restored['packages']['wechat']['folder'], 'content.md').read_text(encoding='utf-8'), '迁移后的作品')
        with other.db() as db:
            payload = db.execute('SELECT payload FROM tasks').fetchone()[0]
            self.assertNotIn('folder', json.loads(payload)['packages']['wechat'])

    def test_html_preview_resource_mapping(self):
        t = self.create()
        folder = Path(t['packages']['wechat']['folder'])
        (folder / 'cover.png').write_bytes(b'png')
        original = '<img src="cover.png"><script>alert(1)</script>'
        (folder / 'article.html').write_text(original, encoding='utf-8')
        self.login()
        endpoint = '/api/tasks/' + t['id'] + '/wechat/file?path=article.html'
        r = self.request(endpoint)
        self.assertEqual(r.status, 200)
        self.assertIn('/file?path=cover.png', r.read().decode('utf-8'))
        self.assertIn('sandbox', r.headers['Content-Security-Policy'])
        self.assertEqual(json.loads(self.request(endpoint + '&text=1').read())['text'], original)

    def test_generation_outputs_and_partial_status(self):
        t = self.create()
        def output_process(args, **kwargs):
            class FakeProcess:
                returncode = 0
                def communicate(self, data):
                    self.prompt = data.decode('utf-8')
                    folder = Path(t['packages']['wechat']['folder'])
                    (folder / 'content.md').write_text('真实执行测试的模拟输出', encoding='utf-8')
                    (folder / 'sources.md').write_text('https://example.com', encoding='utf-8')
                    (folder / 'cover.svg').write_text('<svg/>', encoding='utf-8')
                    self_outer.assertIn('禁止 git push', self.prompt)
                    self_outer.assertIn('workspace-write', args)
            return FakeProcess()
        self_outer = self
        with patch('server.codex_command', return_value=['codex']), patch('server.subprocess.run') as login, patch('server.subprocess.Popen', side_effect=output_process):
            login.return_value.returncode = 0
            login.return_value.stdout = ''
            login.return_value.stderr = 'Logged in using ChatGPT'
            self.app.run_generation(t['id'])
        self.assertEqual(self.app.task(t['id'])['status'], 'partial')
        self.assertIn('抖音', self.app.task(t['id'])['message'])

    def test_git_upload_remote_check_and_conflict(self):
        remote = Path(self.tmp.name) / 'remote.git'
        seed = Path(self.tmp.name) / 'seed'
        repo = Path(self.tmp.name) / 'checkout'
        cmd(['git', 'init', '--bare', '--initial-branch=main', str(remote)])
        cmd(['git', 'clone', str(remote), str(seed)])
        for folder in (seed,):
            cmd(['git', 'config', 'user.name', 'Studio Test'], folder)
            cmd(['git', 'config', 'user.email', 'studio-test@example.invalid'], folder)
        (seed / 'README.md').write_text('test')
        cmd(['git', 'add', 'README.md'], seed)
        cmd(['git', 'commit', '-m', 'init'], seed)
        cmd(['git', 'push', '-u', 'origin', 'main'], seed)
        cmd(['git', 'clone', str(remote), str(repo)])
        cmd(['git', 'config', 'user.name', 'Studio Test'], repo)
        cmd(['git', 'config', 'user.email', 'studio-test@example.invalid'], repo)
        t = self.create()
        folder = Path(t['packages']['wechat']['folder'])
        (folder / 'content.md').write_text('要上传的素材', encoding='utf-8')
        with patch.object(self.app, 'repo', return_value=repo):
            url = self.app.publish(t['id'], 'wechat')
            self.assertIn('/weixin/tree/main/articles/', url)
            sha = self.app.task(t['id'])['packages']['wechat']['commit']
            self.assertEqual(cmd(['git', 'ls-remote', str(remote), 'refs/heads/main']).split()[0], sha)
            remote_path = self.app.task(t['id'])['packages']['wechat']['remote_path']
            cmd(['git', 'pull', '--ff-only'], seed)
            (seed / remote_path / 'content.md').write_text('另一个客户端修改', encoding='utf-8')
            cmd(['git', 'add', '--', remote_path], seed)
            cmd(['git', 'commit', '-m', 'outside edit'], seed)
            cmd(['git', 'push'], seed)
            with self.assertRaisesRegex(ValueError, '远端素材已变化'):
                self.app.publish(t['id'], 'wechat')

    def test_import_versions_deduplicate_and_preserve_local_edits(self):
        repo = Path(self.tmp.name) / 'import-repo'
        cmd(['git', 'init', '--initial-branch=main', str(repo)])
        cmd(['git', 'config', 'user.name', 'Studio Test'], repo)
        cmd(['git', 'config', 'user.email', 'studio-test@example.invalid'], repo)
        package = repo / 'articles' / 'example-topic'
        package.mkdir(parents=True)
        source = package / 'content.md'
        source.write_text('仓库原始版本', encoding='utf-8')
        cmd(['git', 'add', '--', 'articles'], repo)
        cmd(['git', 'commit', '-m', 'Initial package'], repo)
        platforms = {'wechat': {'name': '公众号', 'repo': 'weixin', 'prefix': 'articles'}}
        with patch('server.PLATFORMS', platforms):
            self.assertEqual(self.app.import_existing({'wechat': repo}), 1)
            original = self.app.all_tasks()[0]
            original_file = Path(original['packages']['wechat']['folder']) / 'content.md'
            original_file.write_text('尚未上传的本地编辑', encoding='utf-8')
            self.assertEqual(self.app.import_existing({'wechat': repo}), 0)
            self.assertEqual(len(self.app.all_tasks()), 1)

            source.write_text('仓库最新版本', encoding='utf-8')
            cmd(['git', 'add', '--', 'articles'], repo)
            cmd(['git', 'commit', '-m', 'Remote package update'], repo)
            self.assertEqual(self.app.import_existing({'wechat': repo}), 1)
            tasks = self.app.all_tasks()
            self.assertEqual(len(tasks), 2)
            latest = next(t for t in tasks if t['id'] != original['id'])
            self.assertIn('远端更新', latest['topic'])
            self.assertEqual(original_file.read_text(encoding='utf-8'), '尚未上传的本地编辑')
            self.assertEqual(Path(latest['packages']['wechat']['folder'], 'content.md').read_text(encoding='utf-8'), '仓库最新版本')
            self.assertEqual(latest['packages']['wechat']['remote_path'], original['packages']['wechat']['remote_path'])
            self.assertNotEqual(latest['packages']['wechat']['tree'], original['packages']['wechat']['tree'])
            self.assertEqual(self.app.import_existing({'wechat': repo}), 0)
            self.assertEqual(len(self.app.all_tasks()), 2)

    def test_cancel_while_checking_login_does_not_launch_generation(self):
        t = self.create()
        t['status'] = 'queued'
        self.app.save(t)
        def login(*args, **kwargs):
            self.app.cancel(t['id'])
            from subprocess import CompletedProcess
            return CompletedProcess(args, 0, '', 'Logged in using ChatGPT')
        with patch('server.codex_command', return_value=['codex']), patch('server.subprocess.run', side_effect=login), patch('server.subprocess.Popen') as spawn:
            self.app.run_generation(t['id'])
            spawn.assert_not_called()
        self.assertEqual(self.app.task(t['id'])['status'], 'cancelled')

if __name__ == '__main__':
    unittest.main()
