import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import main


class StartupTests(unittest.TestCase):
    def test_duplicate_start_does_not_mutate_running_tasks(self):
        with patch('sys.argv', ['server.py']), patch('server.ThreadingHTTPServer', side_effect=OSError('port in use')), patch('server.Studio') as studio, patch('builtins.print'):
            main()
            studio.assert_not_called()
