# Platform packages

Choose the exact files and lengths according to the topic and what the destination repository already uses. These are output expectations, not rigid templates.

| Platform | Reviewable result |
| --- | --- |
| WeChat Official Account | A substantial article with headline, lead, clear sections, practical conclusion, cover and useful in-body visuals. Provide a clean copy/paste form such as HTML when it helps manual publication, plus source notes. |
| Xiaohongshu | A concise post caption and an ordered sequence of mobile-readable vertical cards or equivalent visual assets. Use a strong first-card hook, specific takeaways, and restrained tags. Include card order and source notes. |
| Toutiao | A distinct explanatory article suited to reading in a feed, with a clear title, summary/lead, cover and useful body visuals. Provide copy/paste HTML if practical, plus source notes. |
| Douyin | A playable vertical video when feasible, a cover, posting caption, subtitles, script/storyboard, and editable scene/audio assets where produced. Check playback, spoken/subtitle consistency, framing, and legibility. Include source notes. |

Shared research can feed all four outputs. The finished titles, structure, emphasis, and visuals should each fit the platform. Do not require a fixed account persona, a fixed card count, or a fixed video duration. State the date and basis for any ranked list; explain why a ranking may differ from real-world experience when relevant.

Source notes should connect key factual claims to URLs, publisher and publication or access date. Separate image/audio provenance from factual sources. Where there are contested facts, either resolve the difference with evidence or describe it accurately in the content.
