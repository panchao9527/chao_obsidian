# GitHub destinations

The user explicitly designated these repositories for finished materials. Repository names are exact; `titok` is the existing Douyin repository name.

| Platform | Repository | Existing example folder convention |
| --- | --- | --- |
| WeChat Official Account | https://github.com/panchao9527/weixin | `articles/YYYY-MM-DD-主题/` |
| Xiaohongshu | https://github.com/panchao9527/xiaohongshu | `posts/YYYY-MM-DD-主题/` |
| Toutiao | https://github.com/panchao9527/jinritoutiao | `articles/YYYY-MM-DD-主题/` |
| Douyin | https://github.com/panchao9527/titok | `videos/YYYY-MM-DD-主题/` |

Before writing, inspect the live repositories, default branches, relevant examples, and any repository instructions. Use an existing suitable checkout or clone into a task workspace. Preserve unrelated files and changes. Choose a short, filesystem-safe topic slug and avoid overwriting an older package; reconcile same-day duplicates deliberately.

Stage only the intended package files. Commit descriptive messages and push to the repository's established destination branch. Confirm the remote commit and package paths after each push; if a push response is ambiguous, inspect the remote before retrying. Do not use `git add .` in a dirty checkout. Do not create a pull request or change repository settings unless the user asks.

Link the actual remote package folders in the handoff, and give the user a short file-order or manual upload note if the media sequence is not obvious. Uploading to GitHub is delivery of source materials only; it does not authorize posting on social platforms.
