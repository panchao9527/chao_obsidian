---
name: topic-to-four-platforms
description: For this user's established one-topic-four-platform workflow. Use when the user gives a topic, including a bare topic in this ongoing content workflow, to research and prepare distinct Chinese materials for WeChat Official Account, Xiaohongshu, Toutiao, and Douyin, then upload those materials to the four configured GitHub repositories for the user to publish manually.
---

# One topic, four platform packages

Given a topic, complete all four platform packages and push each to its configured GitHub repository. A bare topic in this user's established workflow is enough to start. If the user narrows the scope to certain platforms, a plan, or local drafts, follow that narrower request. Do not create or submit social-platform drafts, publish posts, or operate the user's social accounts unless separately requested.

## Work

1. Clarify only missing information that materially changes correctness or scope. Otherwise choose a useful angle and audience, and state any consequential assumption. Inspect existing examples in the destination repositories before choosing file layout or style; treat them as examples, not fixed templates.
2. Research the topic from current, attributable sources when facts may have changed or source accuracy matters. Build one shared fact base with claim-to-source links and a clear as-of date. Distinguish measured data, manufacturer claims, analysis, and opinion. Check current platform requirements from official sources when a requirement affects the deliverable. Never invent rankings, test results, quotations, usage rights, or links.
3. Create four genuinely platform-native versions from the shared facts. Read [platform packages](references/platform-packages.md) for deliverable expectations. Tailor depth, title, hook, text, visual sequence, and call to action to each platform and topic. Avoid copying the same article or card deck into all four repositories. Create usable media, not just prompts for media, when the local tools support it.
4. Keep each package reviewable: final copy, media assets, an asset order or storyboard where needed, and source notes. Check Chinese text, legibility on a phone, media dimensions/playback, factual consistency, and file completeness. Mark genuinely unverified claims or partial assets plainly.
5. Read [GitHub destinations](references/github-destinations.md), then commit and push each completed package to its mapped repository. Verify the remote state after each push. If access, rendering, or push fails, preserve finished work and report the exact remaining step rather than claiming completion.
6. Report four repository links, what each package contains, the research as-of date, and any concrete limitation. The user handles all publishing inside WeChat, Xiaohongshu, Toutiao, and Douyin.

## Boundaries

- The standing GitHub upload request covers only the four repositories named in `references/github-destinations.md` for this workflow. A different repository or a social-platform write needs a separate user request.
- Never place credentials, private account data, copyrighted source files without reuse rights, or unrelated local files in a package. Use original graphics or licensed assets, and record material asset provenance.
- If the topic depends on volatile rankings, prices, rules, dates, or availability, verify them for this run and label the snapshot date. Do not reuse a previous article's numbers as current facts.
- A script or storyboard alone is not a finished Douyin video. When video generation is feasible, deliver and inspect a playable vertical video plus editable supporting assets. If it is infeasible, deliver the best complete production kit and describe the missing render clearly.
